<?

/* ANS Output : is 21,21 

Reason : Because the $b is having the reference of $a Whenever we update value for B A will be automatically updated.


**/