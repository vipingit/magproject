<?php

namespace Born\OrderController\Api;

 
interface GuestorderInterface
{
 
    public function getGuestOrderHistory($param);
}